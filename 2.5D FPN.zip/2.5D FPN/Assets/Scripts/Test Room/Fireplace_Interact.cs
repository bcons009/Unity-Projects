﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fireplace_Interact : Interact
{
    protected override void Dialog_Init()
    {
        dialog.Add("Yo!!");
        dialog.Add("What'cha think?");
        dialog.Add("All work and no play makes Jack a dull boy.");
    }

    protected override void Pos_Init()
    {
        pos = "+Y";
    }
}
