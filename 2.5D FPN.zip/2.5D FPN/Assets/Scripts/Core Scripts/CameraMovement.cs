﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{

    private GameObject player;

    public float xOffset;
    public float yOffset;
    public float zOffset;
    public float xRotation;

    public float x_Min;
    public float x_Max;
    public float y_Min;
    public float y_Max;
    public float z_Min;
    public float z_Max;

    private float fixed_Z;
    private Vector3 playerFollow;

    public bool follow;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindWithTag("Player");
        fixed_Z = player.transform.position.z;

        if (follow)
        {
            if (x_Min != 0.0f || x_Max != 0.0f)
            {
                if (player.transform.position.x < x_Min)
                    playerFollow.x = x_Min;
                else if (player.transform.position.x > x_Max)
                    playerFollow.x = x_Max;
                else
                    playerFollow.x = player.transform.position.x;
            }

            if (y_Min != 0.0f || y_Max != 0.0f)
            {
                if (player.transform.position.y < y_Min)
                    playerFollow.y = y_Min;
                else if (player.transform.position.y > y_Max)
                    playerFollow.y = y_Max;
                else
                    playerFollow.y = player.transform.position.y;
            }

            if (z_Min != 0.0f || z_Max != 0.0f)
            {
                if (player.transform.position.z < z_Min)
                    playerFollow.z = z_Min;
                else if (player.transform.position.z > z_Max)
                    playerFollow.z = z_Max;
                else
                    playerFollow.z = player.transform.position.z;
            }
        }
    }

    // Run right after Update()
    void LateUpdate()
    {
        if (!follow)
        {
            playerFollow = new Vector3(player.transform.position.x, player.transform.position.y, fixed_Z);
            transform.position = (playerFollow + new Vector3(xOffset, yOffset, zOffset));
        }
        else
        {
            if ((x_Min != 0.0f || x_Max != 0.0f) && player.transform.position.x > x_Min && player.transform.position.x < x_Max)
            {
                playerFollow.x = player.transform.position.x;
            }
            else if (x_Min == 0.0f && x_Max == 0.0f)
            {
                playerFollow.x = player.transform.position.x;
            }

            if ((y_Min != 0.0f || y_Max != 0.0f) && player.transform.position.y > y_Min && player.transform.position.y < y_Max)
            {
                playerFollow.y = player.transform.position.y;
            }
            else if (y_Min == 0.0f && y_Max == 0.0f)
            {
                playerFollow.y = player.transform.position.y;
            }

            if ((z_Min != 0.0f || z_Max != 0.0f) && player.transform.position.z > z_Min && player.transform.position.z < z_Max)
            {
                playerFollow.z = player.transform.position.z;
            }
            else if (z_Min == 0.0f && z_Max == 0.0f)
            {
                playerFollow.z = player.transform.position.z;
            }

            transform.position = (playerFollow + new Vector3(xOffset, yOffset, zOffset));
        }        

        // For testing purposes only; final game will have fixed camera rotation
        transform.rotation = Quaternion.Euler(xRotation, 0, 0);

        // To follow player on Z-axis, replace "transform.position" line with this:
        // transform.position = player.transform.position + new Vector3(xOffset, yOffset, zOffset);

        // TODO: Keep camera from scrolling outside of rooms
    }
}
