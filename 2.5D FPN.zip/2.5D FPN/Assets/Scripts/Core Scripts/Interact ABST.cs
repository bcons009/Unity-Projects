﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class Interact : MonoBehaviour
{
    private Controller con;
    private Animator anim;

    private GameObject dialogBox;
    private Text dialogText;

    // ArrayList to hold every text box's worth of dialogue.
        //E xample: If there are two lines that must be displayed one at a time, those lines are stored under one index each of the ArrayList.
    protected List<string> dialog = new List<string>();
    public bool playerInRange;
    protected List<string>.Enumerator em;

    // True: Dialog is being displayed
    // False: No dialog is being displayed
    private bool dialog_displaying = false;

    protected string pos;

    // Scrolling text variables"
        // Is text currently being scrolled?
    private bool isTyping = false;
        // Did the player want to skip scrolling?
    private bool skipTyping = false;
        // Speed of text scrolls
    private float textSpeed;
        // Speed of text sound
    private float sfxSpeed;

    protected AudioSource dialog_sfx;
    public AudioClip sfx;

    // Initialize dialog List here
    protected abstract void Dialog_Init();

    // Initialize facing position to interact
        // "+X" = right
        // "-X" = left
        // "+Z" = up
        // "-Z" = down
        // else = none (object will be interactable regardless of where the player is facing)
    protected abstract void Pos_Init();

    // TODO: Create a "Char_Init()" abstract function, initializes character portraits, names (?), and other info for when character is talking
        // Create function in Interact class to handle displaying character portraits, but only if a character is talking

    // Start is called before the first frame update
    void Start()
    {
        con = GameObject.FindWithTag("Player").GetComponent<Controller>();
        anim = GameObject.FindWithTag("Player").GetComponent<Animator>();

        dialogBox = GameObject.Find("/Canvas Manager/Canvas/Dialog Box");
        dialogText = GameObject.Find("/Canvas Manager/Canvas/Dialog Box/Text").GetComponent<Text>();

        dialog_sfx = GetComponent<AudioSource>();

        // TEXT SPEED SET HERE!!
        textSpeed = 0.025f;

        // SFX SPEED SET HERE!!
        sfxSpeed = 0.03f;

        Pos_Init();
        Dialog_Init();
    }
    

    // Update is called once per frame
    void Update()
    {
        // If player interacts with object and no dialogue is displayed...
        if (Input.GetKeyDown(KeyCode.Space) && playerInRange && check_pos() && !dialog_displaying)
        {
            // Begin dialog list
            dialog_displaying = true;

            // New enumerator every time object is first interacted with; makes dialogue begin anew.
            em = dialog.GetEnumerator();

            // Freezes player movement
            con.enabled = false;

            // Default to idle animations
            anim.SetBool("moving", false);

            call_dialog();
        }
        // If player interacts with object and dialogue for that object is already being displayed...
        else if (Input.GetKeyDown(KeyCode.Space) && playerInRange && check_pos() && dialog_displaying)
        {
            if (isTyping)
                skipTyping = true;
            else
                call_dialog();
        }            
    }

    // Actually handles displaying dialogue
    private void call_dialog()
    {        
        if (em.MoveNext())
        {
            // Display dialogue box if not already displayed
            if (!dialogBox.activeInHierarchy)
                dialogBox.SetActive(true);
            // Call Enumerator for scrolling text
            StartCoroutine(TextScroll(em.Current));
        }
        else
        {
            // Hide dialogue box
            dialogBox.SetActive(false);
            // Indicates that dialog list is over
            dialog_displaying = false;

            // Unfreeze player
            con.enabled = true;
        }
    }

    // Code to check if player is facing interactable object
    private bool check_pos()
    {
        bool in_pos;
        switch (pos)
        {
            case "+X":
                if (anim.GetFloat("moveX") == 1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            case "-X":
                if (anim.GetFloat("moveX") == -1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            case "+Z":
                if (anim.GetFloat("moveZ") == 1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            case "-Z":
                if (anim.GetFloat("moveZ") == -1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            default:
                in_pos = true;
                break;
        }
        return in_pos;
    }

    // Enumerator to handle text scrolling
    private IEnumerator TextScroll(string text_line)
    {
        isTyping = true;
        skipTyping = false;

        string visible_text = "";
        string hidden_text = text_line;
        string color_s = "<color=#00000000>";
        string color_f = "</color>";
        
        int letter = 0;
        int dialog_length = text_line.Length;

        dialogText.text = visible_text + color_s + hidden_text + color_f;

        // Start coroutine for text sounds
        StartCoroutine(Text_SFX());

        while (isTyping && !skipTyping && (letter < dialog_length - 1))
        {
            // Add a character from string to dialog text being displayed
            // dialogText.text += text_line[letter];

            char temp = text_line[letter];
            visible_text += temp;
            hidden_text = text_line.Remove(0, letter);
            
            dialogText.text = visible_text + color_s + hidden_text + color_f;

            letter += 1;

            // Don't wait around for space characters
            if (temp.Equals(" "))
                break;

            yield return new WaitForSeconds(textSpeed);
        }
        
        // Displays full text (important to display full text when skipped)
        dialogText.text = text_line;

        // Full text has been displayed; text is neither typing nor skippable.
        isTyping = false;
        skipTyping = false;
    }

    // Enumerator handles text SFX looping separately from text scrolling (avoids weird sound overlapping)
    private IEnumerator Text_SFX()
    {
        while (isTyping)
        {
            dialog_sfx.PlayOneShot(sfx);
            yield return new WaitForSeconds(sfxSpeed);
        }
    }

    // OnTriggers check if player is in range to interact with object/character
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
        }
    }
}
