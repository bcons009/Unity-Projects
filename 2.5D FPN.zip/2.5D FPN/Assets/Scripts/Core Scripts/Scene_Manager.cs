﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene_Manager : MonoBehaviour
{
    public Animator animator;
    private string levelName;

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetMouseButtonDown(0))
            //FadeToLevel("Test Scene 2");
    }

    public void FadeToLevel (string levelName)
    {
        this.levelName = levelName;
        animator.SetTrigger("FadeOut");
    }

    public void OnFadeComplete()
    {
        SceneManager.LoadScene(levelName, LoadSceneMode.Single);
    }
}
