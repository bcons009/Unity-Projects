﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Behind_Transparent : MonoBehaviour
{

    private GameObject parentObj;
    private SpriteRenderer sprite_render;

    private Color transp;

    // Duration of Lerp in seconds
    public float lerpTime;

    // Start is called before the first frame update
    void Start()
    {
        parentObj = this.transform.parent.gameObject;
        sprite_render = parentObj.GetComponent<SpriteRenderer>();
        sprite_render.color = Color.white;
        transp = new Color(1.0f, 1.0f, 1.0f, 0.45f);
    }

    // Update is called once per frame
    void Update()
    {

    }

    // OnTriggers check if player is behind parent object
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(toTransp());
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(toWhite());
        }
    }

    private IEnumerator toTransp()
    {
        float elapsedTime = 0.0f;
        while (elapsedTime < lerpTime)
        {
            elapsedTime += Time.deltaTime;
            sprite_render.color = Color.Lerp(Color.white, transp, (elapsedTime / lerpTime));
            yield return null;
        }
        
    }

    private IEnumerator toWhite()
    {
        float elapsedTime = 0.0f;
        while (elapsedTime < lerpTime)
        {
            elapsedTime += Time.deltaTime;
            sprite_render.color = Color.Lerp(transp, Color.white, (elapsedTime / lerpTime));
            yield return null;
        }        
    }
}
