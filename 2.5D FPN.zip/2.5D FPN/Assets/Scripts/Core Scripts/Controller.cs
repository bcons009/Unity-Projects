﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{

    public float speed;
    public float grav;
    private CharacterController con;
    private Vector3 change;
    
    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        con = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal");
        change.z = Input.GetAxisRaw("Vertical");
        change.y = change.y + Physics.gravity.y * grav;

        UpdateAnim_Move();
    }

    void UpdateAnim_Move()
    {
        // Move "MoveChar();" out here if you want gravity to affect the character without player input
        if (change.x != 0f || change.z != 0f)
        {
            MoveChar();
            anim.SetFloat("moveX", change.x);
            anim.SetFloat("moveZ", change.z);
            anim.SetBool("moving", true);
        }
        else
        {
            MoveChar();
            anim.SetBool("moving", false);            
        }
    }

    void MoveChar()
    {
        con.Move(change * speed * Time.deltaTime);
    }
}
