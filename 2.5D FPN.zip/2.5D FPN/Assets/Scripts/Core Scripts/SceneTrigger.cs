﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneTrigger : MonoBehaviour
{

    private Controller con;
    private Animator anim;
    private Scene_Manager sm;

    public string loadLevel;
    private bool playerInRange = false;

    // Start is called before the first frame update
    void Start()
    {
        con = GameObject.FindWithTag("Player").GetComponent<Controller>();
        anim = GameObject.FindWithTag("Player").GetComponent<Animator>();

        sm = GameObject.Find("/Canvas Manager").GetComponent<Scene_Manager>();

        // Makes sure player controller/animator wakes up from being disabled in the previous scene
            // TEST IF THIS IS NECESSARY
        con.enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && playerInRange)
        {
            con.enabled = false;
            anim.SetBool("moving", false);

            sm.FadeToLevel(loadLevel);
        }
    }

    // OnTriggers check if player is in range to interact with exit
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
        }
    }
}
