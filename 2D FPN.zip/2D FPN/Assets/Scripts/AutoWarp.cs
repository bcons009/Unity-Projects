﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class AutoWarp : MonoBehaviour
{
    public Vector2 newWarpPos;
    private GameObject player;
    private Controller con;
    private Animator anim;

    private Image FadeImg;
    private float fadeSpeed = 0.75f;

    // Start is called before the first frame update
    void Awake()
    {
        FadeImg = GameObject.Find("/Canvas/Fade Black").GetComponent<Image>();

        FadeImg.rectTransform.localScale = new Vector2(Screen.width, Screen.height);
        FadeImg.color = Color.clear;
        FadeImg.enabled = false;

        player = GameObject.FindWithTag("Player");
        con = player.GetComponent<Controller>();
        anim = player.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            //warp_func();
        }
    }

    /*
    private IEnumerator Warp_Coroutine()
    {
        // Stop player movement / freeze animation
        con.enabled = false;
        anim.speed = 0;

        // Fade to black
        FadeImg.enabled = true;
        FadeImg.color = Color.Lerp(FadeImg.color, Color.black, fadeSpeed * Time.deltaTime);

        // Change player transform.position to newWarpPos
        player.transform.position = newWarpPos;

        // Hold black for fadeSpeed seconds
        yield return new WaitForSeconds(fadeSpeed);

        // Default animation to idle
        anim.SetBool("moving", false);

        // Fade to clear
        FadeImg.color = Color.Lerp(FadeImg.color, Color.clear, fadeSpeed * Time.deltaTime);
        if (FadeImg.color.a <= 0.05f)
        {
            FadeImg.color = Color.clear;
            FadeImg.enabled = false;
        }

        // Turn player movement / animation back on
        anim.speed = 1;
        con.enabled = true;
    }
    */

    // https://www.youtube.com/watch?time_continue=81&v=MkoIZTFUego&feature=emb_title
}
