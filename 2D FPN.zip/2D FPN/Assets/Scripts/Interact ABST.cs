﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class Interact : MonoBehaviour
{
    private Controller con;
    private Animator anim;

    public GameObject dialogBox;
    public Text dialogText;

    // ArrayList to hold every text box's worth of dialogue.
        //E xample: If there are two lines that must be displayed one at a time, those lines are stored under one index each of the ArrayList.
    protected List<string> dialog = new List<string>();
    public bool playerInRange;
    protected List<string>.Enumerator em;

    // True: Dialog is being displayed
    // False: No dialog is being displayed
    private bool dialog_displaying = false;

    protected string pos;

    // Scrolling text variables"
        // Is text currently being scrolled?
    private bool isTyping = false;
        // Did the player want to skip scrolling?
    private bool skipTyping = false;
        // Speed of text scrolls
    private float textSpeed;

    protected AudioSource dialog_sfx;

    // Initialize dialog List here
    protected abstract void Dialog_Init();

    // Initialize facing position to interact
        // "+X" = right
        // "-X" = left
        // "+Y" = up
        // "-Y" = down
        // else = error (object will not interactable)
    protected abstract void Pos_Init();

    // Start is called before the first frame update
    void Start()
    {
        con = GameObject.FindWithTag("Player").GetComponent<Controller>();
        anim = GameObject.FindWithTag("Player").GetComponent<Animator>();
        dialog_sfx = GetComponent<AudioSource>();

        // TEXT SPEED SET HERE!!
        textSpeed = 0.03f;

        Pos_Init();
        Dialog_Init();
    }
    

    // Update is called once per frame
    void Update()
    {
        // If player interacts with object and no dialogue is displayed...
        if (Input.GetKeyDown(KeyCode.Space) && playerInRange && check_pos() && !dialog_displaying)
        {
            // Begin dialog list
            dialog_displaying = true;

            // New enumerator every time object is first interacted with; makes dialogue begin anew.
            em = dialog.GetEnumerator();

            // Freezes player movement
            con.enabled = false;

            // Default to idle animations
            anim.SetBool("moving", false);

            call_dialog();
        }
        // If player interacts with object and dialogue for that object is already being displayed...
        else if (Input.GetKeyDown(KeyCode.Space) && playerInRange && check_pos() && dialog_displaying)
        {
            if (isTyping)
                skipTyping = true;
            else
                call_dialog();
        }            
    }

    // Actually handles displaying dialogue
    private void call_dialog()
    {        
        if (em.MoveNext())
        {
            // Display dialogue box if not already displayed
            if (!dialogBox.activeInHierarchy)
                dialogBox.SetActive(true);
            // Call Enumerator for scrolling text
            StartCoroutine(TextScroll(em.Current));
        }
        else
        {
            // Hide dialogue box
            dialogBox.SetActive(false);
            // Indicates that dialog list is over
            dialog_displaying = false;

            // Unfreeze player
            con.enabled = true;
        }
    }

    // Code to check if player is facing interactable object
    private bool check_pos()
    {
        bool in_pos;
        switch (pos)
        {
            case "+X":
                if (anim.GetFloat("moveX") == 1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            case "-X":
                if (anim.GetFloat("moveX") == -1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            case "+Y":
                if (anim.GetFloat("moveY") == 1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            case "-Y":
                if (anim.GetFloat("moveY") == -1.0)
                    in_pos = true;
                else
                    in_pos = false;
                break;
            default:
                in_pos = false;
                break;
        }
        return in_pos;
    }

    // Enumerator to handle text scrolling
    private IEnumerator TextScroll(string text_line)
    {
        int letter = 0;
        dialogText.text = "";
        isTyping = true;
        skipTyping = false;
        while (isTyping && !skipTyping && (letter < text_line.Length - 1))
        {
            // Add a character from string to dialog text being displayed
            dialogText.text += text_line[letter];

            // Sound for every character displayed (that isn't a space (?))
            if (!text_line[letter].Equals(" "))
                dialog_sfx.Play(0);
            
            letter += 1;

            yield return new WaitForSeconds(textSpeed);
        }
        dialogText.text = text_line;
        isTyping = false;
        skipTyping = false;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
        }
    }
}
