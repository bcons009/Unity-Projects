﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bookshelf_Interact : Interact
{
    protected override void Dialog_Init()
    {
        dialog.Add("Dusty copies of Stephen King novels line the rotting bookshelf.");
        dialog.Add("Kinda cringe tbh");
    }

    protected override void Pos_Init()
    {
        pos = "+Y";
    }
}
